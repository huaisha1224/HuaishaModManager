---@enum EChaosClothTetherMode
EChaosClothTetherMode = {
    FastTetherFastLength = 0,
    AccurateTetherFastLength = 1,
    AccurateTetherAccurateLength = 2,
    MaxChaosClothTetherMode = 3,
    EChaosClothTetherMode_MAX = 4,
}

---@enum EChaosWeightMapTarget
EChaosWeightMapTarget = {
    None = 0,
    MaxDistance = 1,
    BackstopDistance = 2,
    BackstopRadius = 3,
    AnimDriveStiffness = 4,
    AnimDriveDamping = 5,
    TetherStiffness = 6,
    TetherScale = 7,
    Drag = 8,
    Lift = 9,
    EdgeStiffness = 10,
    BendingStiffness = 11,
    AreaStiffness = 12,
    CollisionThicknessScale = 13,
    EChaosWeightMapTarget_MAX = 14,
}

